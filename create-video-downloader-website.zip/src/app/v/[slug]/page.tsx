import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { ArrowLeftIcon, ArrowRightIcon, ExternalIcon, NoteIcon, StarIcon } from "@/components/icons";
import { PlatformBadge } from "@/components/platform-badge";
import { Player } from "@/components/player";
import { Thumb } from "@/components/thumb";
import { VideoActions } from "@/components/video-actions";
import { hostOf, installedOn, timeAgo } from "@/lib/format";
import { PLATFORM_META } from "@/lib/types";
import { getVideoBySlug, listVideos } from "@/lib/videos";

export const dynamic = "force-dynamic";

type Props = { params: Promise<{ slug: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  try {
    const video = await getVideoBySlug(slug);
    if (!video) return { title: "Install not found" };
    return {
      title: video.title,
      description: `${video.authorName ?? PLATFORM_META[video.platform].label} · installed in reelbase from a ${PLATFORM_META[video.platform].label} link.`,
    };
  } catch {
    return { title: "Install" };
  }
}

function DetailRow({
  label,
  value,
  mono = false,
}: {
  label: string;
  value: string;
  mono?: boolean;
}) {
  return (
    <div className="flex items-start justify-between gap-3">
      <dt className="shrink-0 text-white/35">{label}</dt>
      <dd
        className={`min-w-0 truncate text-right text-chalk/85 ${mono ? "font-mono text-[10.5px]" : ""}`}
      >
        {value}
      </dd>
    </div>
  );
}

export default async function VideoPage({ params }: Props) {
  const { slug } = await params;

  let video;
  try {
    video = await getVideoBySlug(slug);
  } catch {
    video = null;
  }
  if (!video) notFound();

  let all: Awaited<ReturnType<typeof listVideos>> = [];
  try {
    all = await listVideos();
  } catch {
    all = [];
  }

  const related = all
    .filter((item) => item.id !== video!.id)
    .sort((a, b) => {
      const score = (platform: string) => (platform === video!.platform ? 1 : 0);
      return score(b.platform) - score(a.platform) || b.installCount - a.installCount;
    })
    .slice(0, 3);

  const meta = PLATFORM_META[video!.platform];
  const playerLabel =
    video!.playerKind === "iframe"
      ? "embedded iframe"
      : video!.playerKind === "video"
        ? "native file"
        : "outbound link";

  return (
    <>
      <SiteHeader />

      <main className="mx-auto w-full max-w-6xl px-5 pb-4 pt-7">
        <Link
          href="/#library"
          className="inline-flex items-center gap-2 text-[12px] text-fog transition hover:text-chalk"
        >
          <ArrowLeftIcon className="h-3.5 w-3.5" /> Back to library
        </Link>

        <div className="mt-5 grid gap-6 lg:grid-cols-[minmax(0,1fr)_330px] lg:items-start">
          <div className="min-w-0">
            <div className="flex flex-wrap items-center gap-2">
              <PlatformBadge platform={video!.platform} size="md" />
              <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/45">
                installed {installedOn(video!.createdAt)}
              </span>
              {video!.installCount > 1 && (
                <span className="rounded-full border border-white/[0.08] bg-white/[0.03] px-2.5 py-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/45">
                  re-installed ×{video!.installCount}
                </span>
              )}
              {video!.favorite && (
                <span className="inline-flex items-center gap-1 rounded-full border border-lime/30 bg-lime/10 px-2.5 py-1 font-mono text-[9.5px] uppercase tracking-[0.14em] text-lime">
                  <StarIcon className="h-3 w-3" filled /> starred
                </span>
              )}
            </div>

            <h1 className="mt-4 text-balance text-[25px] font-semibold leading-[1.12] tracking-[-0.035em] text-chalk sm:text-[34px]">
              {video!.title}
            </h1>

            <div className="mt-2.5 flex flex-wrap items-center gap-x-2.5 gap-y-1 text-[12.5px] text-fog">
              {video!.authorUrl ? (
                <a
                  href={video!.authorUrl}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="font-medium text-chalk/85 underline decoration-white/20 underline-offset-4 transition hover:text-lime"
                >
                  {video!.authorName ?? hostOf(video!.authorUrl)}
                </a>
              ) : (
                <span className="font-medium text-chalk/85">
                  {video!.authorName ?? meta.label}
                </span>
              )}
              <span className="text-white/20">·</span>
              <span>{hostOf(video!.canonicalUrl)}</span>
              <span className="text-white/20">·</span>
              <span>updated {timeAgo(video!.updatedAt)}</span>
            </div>

            <div className="mt-5">
              <Player video={video!} />
            </div>

            <div className="mt-5 flex flex-col gap-2.5 rounded-2xl border border-white/[0.07] bg-panel/50 p-3.5 sm:flex-row sm:items-center">
              <div className="min-w-0 flex-1">
                <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-white/30">
                  original source
                </p>
                <p className="mt-1.5 truncate font-mono text-[11px] text-white/55">
                  {video!.canonicalUrl}
                </p>
              </div>
              <a
                href={video!.canonicalUrl}
                target="_blank"
                rel="noreferrer noopener"
                className="inline-flex shrink-0 items-center justify-center gap-1.5 rounded-xl border border-white/12 bg-white/[0.04] px-3 py-2 text-[11.5px] font-medium text-chalk transition hover:border-lime/40 hover:text-lime"
              >
                <ExternalIcon className="h-3.5 w-3.5" /> Open source
              </a>
            </div>

            {video!.note && (
              <div className="mt-3 rounded-2xl border border-white/[0.07] bg-white/[0.02] p-4">
                <p className="flex items-center gap-1.5 font-mono text-[9px] uppercase tracking-[0.18em] text-white/30">
                  <NoteIcon className="h-3 w-3" /> note on this install
                </p>
                <p className="mt-2 whitespace-pre-wrap text-[13px] leading-relaxed text-chalk/80">
                  {video!.note}
                </p>
              </div>
            )}

            {related.length > 0 && (
              <section className="mt-10">
                <div className="flex items-end justify-between gap-3">
                  <h2 className="text-[17px] font-semibold tracking-[-0.02em] text-chalk">
                    More from your library
                  </h2>
                  <Link
                    href="/#library"
                    className="inline-flex items-center gap-1 font-mono text-[9.5px] uppercase tracking-[0.16em] text-white/35 transition hover:text-lime"
                  >
                    view all <ArrowRightIcon className="h-3 w-3" />
                  </Link>
                </div>
                <div className="mt-4 grid gap-3 sm:grid-cols-3">
                  {related.map((item) => (
                    <Link
                      key={item.id}
                      href={`/v/${item.slug}`}
                      className="group overflow-hidden rounded-xl border border-white/[0.07] bg-panel/50 transition hover:-translate-y-0.5 hover:border-white/20"
                    >
                      <Thumb
                        src={item.thumbnailUrl}
                        alt={item.title}
                        platform={item.platform}
                        title={item.title}
                        compact
                        className="aspect-video w-full"
                      />
                      <div className="p-2.5">
                        <p className="line-clamp-2 text-[12px] font-medium leading-snug text-chalk/90">
                          {item.title}
                        </p>
                        <p className="mt-1 truncate font-mono text-[9px] uppercase tracking-[0.12em] text-white/30">
                          {PLATFORM_META[item.platform].label} · {timeAgo(item.createdAt)}
                        </p>
                      </div>
                    </Link>
                  ))}
                </div>
              </section>
            )}
          </div>

          <aside className="min-w-0 lg:sticky lg:top-20">
            <VideoActions video={video!} />

            <div className="mt-3 rounded-2xl border border-white/[0.08] bg-panel/60 p-3.5">
              <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/35">
                install details
              </p>
              <dl className="mt-3 space-y-2 text-[11.5px]">
                <DetailRow label="Platform" value={meta.label} />
                <DetailRow label="Video id" value={video!.externalId} mono />
                <DetailRow label="Player" value={playerLabel} />
                <DetailRow label="Metadata" value={video!.metadataSource} />
                <DetailRow label="Installed" value={installedOn(video!.createdAt)} />
                <DetailRow label="Last sync" value={installedOn(video!.updatedAt)} />
                <DetailRow label="Install count" value={`×${video!.installCount}`} />
              </dl>
            </div>

            <p className="mt-3 px-1 text-[11px] leading-relaxed text-white/30">
              Installations only store the source link plus metadata. Playback, views and ads stay
              with {meta.label}.
            </p>
          </aside>
        </div>
      </main>

      <SiteFooter />
    </>
  );
}
