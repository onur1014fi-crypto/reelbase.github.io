import Link from "next/link";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { ArrowLeftIcon, LinkIcon } from "@/components/icons";

export default function NotFound() {
  return (
    <>
      <SiteHeader />
      <main className="mx-auto flex w-full max-w-3xl flex-col items-center px-5 py-24 text-center">
        <span className="grid h-14 w-14 place-items-center rounded-2xl border border-white/10 bg-white/[0.03] text-lime">
          <LinkIcon className="h-6 w-6" />
        </span>
        <p className="mt-6 font-mono text-[10px] uppercase tracking-[0.24em] text-white/35">
          404 · not installed
        </p>
        <h1 className="mt-3 text-[30px] font-semibold tracking-[-0.03em] text-chalk sm:text-[38px]">
          That install is not in this library
        </h1>
        <p className="mt-3 max-w-md text-[13.5px] leading-relaxed text-fog">
          The page may have been uninstalled, or the slug belongs to a different library. Paste the
          link again to reinstall it in seconds.
        </p>
        <div className="mt-7 flex flex-wrap items-center justify-center gap-2">
          <Link
            href="/#library"
            className="inline-flex items-center gap-2 rounded-full bg-lime px-4 py-2.5 text-[12.5px] font-semibold text-black transition hover:bg-[#e8ff83]"
          >
            <ArrowLeftIcon className="h-3.5 w-3.5" /> Back to the library
          </Link>
          <Link
            href="/#install"
            className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2.5 text-[12.5px] text-chalk transition hover:border-white/30"
          >
            Install a link
          </Link>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
