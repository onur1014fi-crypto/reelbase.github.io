import { NextResponse } from "next/server";
import { refreshVideoById } from "@/lib/videos";

export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

export async function POST(_request: Request, context: Context) {
  const { id } = await context.params;
  const parsed = Number.parseInt(id, 10);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 400 });
  }

  try {
    const result = await refreshVideoById(parsed);
    if (!result) {
      return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 404 });
    }
    return NextResponse.json({
      ok: true,
      video: result.video,
      resolved: result.resolved,
      note: result.note,
    });
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Metadata refresh failed.";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
