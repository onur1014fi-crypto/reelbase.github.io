import { NextResponse } from "next/server";
import { deleteVideoById, getVideoById, updateVideoById } from "@/lib/videos";

export const dynamic = "force-dynamic";

type Context = { params: Promise<{ id: string }> };

async function resolveId(context: Context): Promise<number | null> {
  const { id } = await context.params;
  const parsed = Number.parseInt(id, 10);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

export async function PATCH(request: Request, context: Context) {
  const id = await resolveId(context);
  if (!id) {
    return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 400 });
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Send a JSON body." }, { status: 400 });
  }

  const input = (body ?? {}) as { favorite?: unknown; note?: unknown; title?: unknown };
  const patch: { favorite?: boolean; note?: string | null; title?: string } = {};

  if (typeof input.favorite === "boolean") patch.favorite = input.favorite;
  if (typeof input.note === "string") patch.note = input.note;
  else if (input.note === null) patch.note = null;
  if (typeof input.title === "string") patch.title = input.title;

  if (Object.keys(patch).length === 0) {
    return NextResponse.json({ ok: false, error: "Nothing to update." }, { status: 400 });
  }

  const video = await updateVideoById(id, patch);
  if (!video) {
    return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 404 });
  }
  return NextResponse.json({ ok: true, video });
}

export async function DELETE(_request: Request, context: Context) {
  const id = await resolveId(context);
  if (!id) {
    return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 400 });
  }

  const video = await getVideoById(id);
  if (!video) {
    return NextResponse.json({ ok: false, error: "Unknown installation." }, { status: 404 });
  }

  const removed = await deleteVideoById(id);
  return NextResponse.json({ ok: removed, slug: video.slug });
}
