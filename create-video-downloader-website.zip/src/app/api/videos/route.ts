import { NextResponse } from "next/server";
import { parseLink } from "@/lib/link";
import { ensureSeeded, installFromUrl, listVideos } from "@/lib/videos";
import type { InstallResponse } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeeded();
  const videos = await listVideos();
  const platforms = new Set(videos.map((video) => video.platform));
  return NextResponse.json({
    ok: true,
    count: videos.length,
    platforms: platforms.size,
    videos,
  });
}

export async function POST(request: Request) {
  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ ok: false, error: "Send a JSON body." }, { status: 400 });
  }

  const url = (body as { url?: unknown })?.url;
  if (typeof url !== "string" || !url.trim()) {
    return NextResponse.json({ ok: false, error: "Paste a link first." }, { status: 400 });
  }
  if (url.length > 2000) {
    return NextResponse.json({ ok: false, error: "That link is too long." }, { status: 400 });
  }

  const parsed = parseLink(url);
  if (!parsed.ok) {
    return NextResponse.json({ ok: false, error: parsed.error }, { status: 400 });
  }

  try {
    const result = await installFromUrl(url);
    const payload: InstallResponse = {
      ok: true,
      created: result.created,
      resolved: result.resolved,
      video: result.video,
    };
    return NextResponse.json(
      { ...payload, note: result.note, platform: result.video.platform },
      { status: result.created ? 201 : 200 },
    );
  } catch (error) {
    const message =
      error instanceof Error ? error.message : "Could not install that link.";
    return NextResponse.json({ ok: false, error: message }, { status: 400 });
  }
}
