import { NextResponse } from "next/server";

export const dynamic = "force-dynamic";

const PRIVATE_HOST =
  /^(localhost|127\.|0\.0\.0\.0|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[::1\]|::1)/i;

function safeRemoteUrl(raw: string | null): URL | null {
  if (!raw) return null;
  let url: URL;
  try {
    url = new URL(raw);
  } catch {
    return null;
  }
  if (url.protocol !== "http:" && url.protocol !== "https:") return null;
  if (PRIVATE_HOST.test(url.hostname) || url.hostname.endsWith(".local")) return null;
  if (!url.hostname.includes(".")) return null;
  return url;
}

function filenameFor(url: URL): string {
  const last = decodeURIComponent(url.pathname.split("/").filter(Boolean).pop() ?? "video");
  return last.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 90) || "video";
}

/**
 * Streams direct video files (MP4/WebM/...) so they can be played inside the
 * app and downloaded. Range headers are forwarded so seeking works.
 */
export async function GET(request: Request) {
  const params = new URL(request.url).searchParams;
  const remote = safeRemoteUrl(params.get("url"));
  if (!remote) {
    return NextResponse.json(
      { ok: false, error: "A public http(s) video url is required." },
      { status: 400 },
    );
  }

  const range = request.headers.get("range");
  const headers: Record<string, string> = {
    "user-agent": "Mozilla/5.0 (compatible; Reelbase/1.0)",
    accept: "video/*,*/*;q=0.8",
  };
  if (range) headers.range = range;

  let upstream: Response;
  try {
    upstream = await fetch(remote, {
      headers,
      redirect: "follow",
      cache: "no-store",
      signal: request.signal,
    });
  } catch {
    return NextResponse.json(
      { ok: false, error: "The remote server did not respond." },
      { status: 502 },
    );
  }

  if (!upstream.ok && upstream.status !== 206) {
    return NextResponse.json(
      { ok: false, error: `Remote server returned ${upstream.status}.` },
      { status: 502 },
    );
  }

  const contentType = upstream.headers.get("content-type") ?? "";
  const isVideo =
    contentType.startsWith("video/") ||
    contentType === "application/octet-stream" ||
    contentType === "binary/octet-stream";
  if (!isVideo) {
    return NextResponse.json(
      { ok: false, error: "That url is not a downloadable video file." },
      { status: 415 },
    );
  }

  const responseHeaders = new Headers();
  responseHeaders.set("content-type", contentType || "video/mp4");
  responseHeaders.set("cache-control", "public, max-age=3600");
  responseHeaders.set("accept-ranges", upstream.headers.get("accept-ranges") ?? "bytes");
  for (const key of ["content-length", "content-range", "etag", "last-modified"]) {
    const value = upstream.headers.get(key);
    if (value) responseHeaders.set(key, value);
  }
  if (params.get("download") === "1") {
    responseHeaders.set(
      "content-disposition",
      `attachment; filename="${filenameFor(remote)}"`,
    );
  }

  return new Response(upstream.body, {
    status: upstream.status,
    headers: responseHeaders,
  });
}
