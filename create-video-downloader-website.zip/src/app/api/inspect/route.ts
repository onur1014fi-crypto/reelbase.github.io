import { NextResponse } from "next/server";
import { parseLink } from "@/lib/link";
import { PLATFORM_META } from "@/lib/types";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const raw = new URL(request.url).searchParams.get("url") ?? "";
  const parsed = parseLink(raw);
  if (!parsed.ok) {
    return NextResponse.json({ ok: false, error: parsed.error });
  }

  const meta = PLATFORM_META[parsed.link.platform];
  return NextResponse.json({
    ok: true,
    link: {
      platform: parsed.link.platform,
      platformLabel: meta.label,
      title: parsed.link.suggestedTitle,
      thumbnailUrl: parsed.link.thumbnailUrl,
      canonicalUrl: parsed.link.canonicalUrl,
      embedUrl: parsed.link.embedUrl,
      playerKind: parsed.link.playerKind,
      authorName: parsed.link.authorName,
    },
  });
}
