import Link from "next/link";
import { SiteFooter, SiteHeader } from "@/components/chrome";
import { Installer } from "@/components/installer";
import { Library } from "@/components/library";
import { PlatformIcon, PlayIcon, SparkIcon, StarIcon } from "@/components/icons";
import { Thumb } from "@/components/thumb";
import { PLATFORM_META, type Platform, type VideoDTO } from "@/lib/types";
import { ensureSeeded, listVideos } from "@/lib/videos";

export const dynamic = "force-dynamic";

const SUPPORT: { platform: Platform; tag: string; detail: string }[] = [
  {
    platform: "youtube",
    tag: "Embedded player",
    detail:
      "Watch pages, Shorts, live urls, youtu.be and /embed links all normalise to a single video id.",
  },
  {
    platform: "tiktok",
    tag: "Vertical player",
    detail:
      "Full @user/video urls install instantly. vm.tiktok.com short links are followed to the real video.",
  },
  {
    platform: "instagram",
    tag: "Embedded reel",
    detail: "Reels, posts and IGTV links load the official Instagram embed in a 9:16 frame.",
  },
  {
    platform: "vimeo",
    tag: "Embedded player",
    detail: "Standard Vimeo urls and channel links resolve to the numeric video id.",
  },
  {
    platform: "file",
    tag: "Native + download",
    detail:
      "Direct MP4, WebM, Ogg and MOV urls stream through the media proxy with seeking and a download button.",
  },
  {
    platform: "twitter",
    tag: "Reference",
    detail: "Post urls are stored with their author and open on X, since players are restricted.",
  },
  {
    platform: "web",
    tag: "Bookmark",
    detail: "Anything else is still installed as a titled reference so no link gets lost.",
  },
];

/** Kept outside the component so the render body stays free of clock reads. */
function countRecent(videos: VideoDTO[]): number {
  const weekAgo = new Date().getTime() - 7 * 24 * 3600 * 1000;
  return videos.filter((video) => new Date(video.createdAt).getTime() >= weekAgo).length;
}

function Stat({
  label,
  value,
  hint,
}: {
  label: string;
  value: number | string;
  hint: string;
}) {
  return (
    <div className="px-5 py-4">
      <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/35">{label}</p>
      <p className="mt-1.5 text-[26px] font-semibold leading-none tracking-[-0.03em] text-chalk">
        {value}
      </p>
      <p className="mt-1.5 text-[11px] text-fog/80">{hint}</p>
    </div>
  );
}

export default async function HomePage() {
  let videos: VideoDTO[] = [];
  let dbError = false;

  try {
    await ensureSeeded();
    videos = await listVideos();
  } catch {
    dbError = true;
  }

  const platformCount = new Set(videos.map((video) => video.platform)).size;
  const starred = videos.filter((video) => video.favorite).length;
  const recent = countRecent(videos);
  const latest = videos[0];
  const justInstalled = videos.slice(0, 3);

  return (
    <>
      <SiteHeader />

      <main>
        <section className="relative overflow-hidden pb-4 pt-14 sm:pt-20">
          <div className="mx-auto w-full max-w-6xl px-5">
            <div className="rise mx-auto max-w-3xl text-center">
              <span className="inline-flex items-center gap-2 rounded-full border border-white/10 bg-white/[0.03] px-3 py-1.5 font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/55">
                <span className="relative flex h-1.5 w-1.5">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-lime opacity-70" />
                  <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-lime" />
                </span>
                link in · player installed
              </span>

              <h1 className="mt-6 text-balance text-[40px] font-semibold leading-[0.98] tracking-[-0.045em] sm:text-[62px] lg:text-[70px]">
                Drop a link.
                <br />
                <span className="text-lime">Install the video.</span>
              </h1>

              <p className="mx-auto mt-5 max-w-xl text-[14.5px] leading-relaxed text-fog sm:text-[16px]">
                Reelbase turns any video url into a permanent installation — a working player, the
                real title and creator, and a page of its own. Mostly YouTube and TikTok, but
                nothing with a video id is turned away.
              </p>

              <div className="mt-8">
                <Installer />
              </div>

              <ul className="mt-2 flex flex-wrap items-center justify-center gap-x-4 gap-y-1.5 font-mono text-[9.5px] uppercase tracking-[0.14em] text-white/30">
                <li>one install per video</li>
                <li aria-hidden="true">•</li>
                <li>real title + thumbnail</li>
                <li aria-hidden="true">•</li>
                <li>re-paste to refresh</li>
              </ul>
            </div>

            {latest && (
              <Link
                href={`/v/${latest.slug}`}
                className="rise group mx-auto mt-10 flex max-w-2xl items-center gap-3 rounded-2xl border border-white/[0.08] bg-panel/50 p-2.5 text-left transition hover:border-white/20 hover:bg-panel sm:mt-12"
              >
                <Thumb
                  src={latest.thumbnailUrl}
                  alt=""
                  platform={latest.platform}
                  title={latest.title}
                  compact
                  className="h-14 w-24 shrink-0 rounded-xl"
                />
                <div className="min-w-0 flex-1">
                  <p className="font-mono text-[9px] uppercase tracking-[0.18em] text-lime/80">
                    latest install
                  </p>
                  <p className="mt-1 truncate text-[13px] font-semibold text-chalk">
                    {latest.title}
                  </p>
                  <p className="truncate text-[11.5px] text-fog">
                    {latest.authorName ?? PLATFORM_META[latest.platform].label}
                    <span className="px-1.5 text-white/20">/</span>
                    {PLATFORM_META[latest.platform].label}
                  </p>
                </div>
                <span className="mr-1 grid h-9 w-9 shrink-0 place-items-center rounded-full border border-white/10 bg-white/[0.04] text-white/70 transition group-hover:border-lime/40 group-hover:text-lime">
                  <PlayIcon className="h-3.5 w-3.5 translate-x-[1px]" />
                </span>
              </Link>
            )}

            {justInstalled.length > 0 && (
              <div className="mt-4 flex flex-wrap items-center justify-center gap-1.5">
                <span className="mr-1 font-mono text-[9px] uppercase tracking-[0.18em] text-white/25">
                  just installed
                </span>
                {justInstalled.map((video) => {
                  const meta = PLATFORM_META[video.platform];
                  return (
                    <Link
                      key={video.id}
                      href={`/v/${video.slug}`}
                      className="inline-flex max-w-[240px] items-center gap-1.5 rounded-full border border-white/[0.07] bg-white/[0.02] px-2.5 py-1 text-[10.5px] text-fog transition hover:border-white/20 hover:text-chalk"
                    >
                      <PlatformIcon
                        platform={video.platform}
                        className="h-3 w-3 shrink-0"
                        style={{ color: meta.accent }}
                      />
                      <span className="truncate">{video.title}</span>
                    </Link>
                  );
                })}
              </div>
            )}
          </div>
        </section>

        {dbError && (
          <div className="mx-auto mt-8 w-full max-w-6xl px-5">
            <p className="rounded-xl border border-amber-300/25 bg-amber-300/[0.06] px-4 py-3 text-[12.5px] text-amber-100">
              The library database is still warming up. Installs will work as soon as the
              connection is ready — reload in a moment.
            </p>
          </div>
        )}

        <section className="mx-auto mt-12 w-full max-w-6xl px-5">
          <div className="grid grid-cols-2 divide-white/[0.06] overflow-hidden rounded-2xl border border-white/[0.08] bg-panel/40 sm:grid-cols-4 sm:divide-x">
            <Stat label="installed" value={videos.length} hint="permanent library entries" />
            <Stat label="platforms" value={platformCount} hint="sources with a player" />
            <Stat label="starred" value={starred} hint="marked to come back to" />
            <Stat label="new this week" value={recent} hint="added in the last 7 days" />
          </div>
        </section>

        <section id="library" className="mx-auto mt-16 w-full max-w-6xl scroll-mt-20 px-5">
          <Library initialVideos={videos} />
        </section>

        <section id="how" className="mx-auto mt-20 w-full max-w-6xl scroll-mt-20 px-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-white/35">
                <SparkIcon className="h-3.5 w-3.5" /> the install path
              </p>
              <h2 className="mt-2 text-[26px] font-semibold tracking-[-0.03em] sm:text-[30px]">
                Three steps, no uploads
              </h2>
            </div>
            <p className="max-w-sm text-[12.5px] leading-relaxed text-fog">
              Nothing is downloaded or re-hosted. The install is the identity of the video plus a
              player that points at the source.
            </p>
          </div>

          <div className="mt-6 grid gap-4 md:grid-cols-3">
            {[
              {
                step: "01",
                title: "Paste the link",
                body:
                  "Copy the url straight from the share sheet or address bar. Watch pages, Shorts, vm.tiktok.com links, Reels and direct files are all understood.",
              },
              {
                step: "02",
                title: "We resolve the video",
                body:
                  "The server detects the platform and video id, then asks the platform's own oEmbed endpoint for the real title, creator and artwork.",
              },
              {
                step: "03",
                title: "It lives in your library",
                body:
                  "One idempotent row per video in Postgres. Every install gets a permanent page, a player and a note field. Paste it again and it refreshes instead of duplicating.",
              },
            ].map((item) => (
              <article
                key={item.step}
                className="rounded-2xl border border-white/[0.07] bg-panel/50 p-5 transition hover:border-white/15"
              >
                <div className="flex items-center justify-between">
                  <span className="font-mono text-[11px] tracking-[0.2em] text-lime/80">
                    {item.step}
                  </span>
                  <span className="h-1.5 w-1.5 rounded-full bg-white/20" />
                </div>
                <h3 className="mt-4 text-[15px] font-semibold text-chalk">{item.title}</h3>
                <p className="mt-2 text-[12.5px] leading-relaxed text-fog">{item.body}</p>
              </article>
            ))}
          </div>
        </section>

        <section id="platforms" className="mx-auto mt-20 w-full max-w-6xl scroll-mt-20 px-5">
          <div className="flex flex-wrap items-end justify-between gap-3">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.22em] text-white/35">
                supported links
              </p>
              <h2 className="mt-2 text-[26px] font-semibold tracking-[-0.03em] sm:text-[30px]">
                One field, seven kinds of link
              </h2>
            </div>
            <a
              href="#install"
              className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-[12.5px] text-chalk transition hover:border-lime/40 hover:text-lime"
            >
              <StarIcon className="h-3.5 w-3.5" /> Try your own
            </a>
          </div>

          <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {SUPPORT.map((item) => {
              const meta = PLATFORM_META[item.platform];
              return (
                <article
                  key={item.platform}
                  className="group rounded-2xl border border-white/[0.07] bg-panel/40 p-4 transition hover:border-white/15 hover:bg-panel/70"
                >
                  <div className="flex items-center gap-2.5">
                    <span
                      className="grid h-9 w-9 place-items-center rounded-xl border border-white/10"
                      style={{ background: meta.tint, color: meta.accent }}
                    >
                      <PlatformIcon platform={item.platform} className="h-4 w-4" />
                    </span>
                    <div>
                      <p className="text-[13px] font-semibold text-chalk">{meta.label}</p>
                      <p className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/35">
                        {item.tag}
                      </p>
                    </div>
                  </div>
                  <p className="mt-3 text-[12px] leading-relaxed text-fog">{item.detail}</p>
                </article>
              );
            })}
          </div>
        </section>

        <section className="mx-auto mt-20 w-full max-w-6xl px-5">
          <div className="relative overflow-hidden rounded-3xl border border-white/[0.08] bg-panel/60 px-6 py-10 text-center sm:px-10">
            <div
              className="pointer-events-none absolute inset-0 opacity-70"
              style={{
                background:
                  "radial-gradient(60% 120% at 50% 0%, rgba(216,255,74,0.14), transparent 65%)",
              }}
            />
            <p className="relative font-mono text-[10px] uppercase tracking-[0.22em] text-lime/80">
              ready when you are
            </p>
            <h2 className="relative mt-3 text-balance text-[28px] font-semibold tracking-[-0.03em] sm:text-[36px]">
              That link in your clipboard?
              <br className="hidden sm:block" /> Install it.
            </h2>
            <p className="relative mx-auto mt-3 max-w-md text-[13px] leading-relaxed text-fog">
              Your library is stored locally in Postgres. Paste once, keep the player forever.
            </p>
            <a
              href="#install"
              className="relative mt-6 inline-flex items-center gap-2 rounded-full bg-lime px-5 py-2.5 text-[13px] font-semibold text-black transition hover:bg-[#e8ff83]"
            >
              <PlayIcon className="h-3.5 w-3.5 translate-x-[1px]" /> Install a video
            </a>
          </div>
        </section>
      </main>

      <SiteFooter />
    </>
  );
}
