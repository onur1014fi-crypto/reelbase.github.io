import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: {
    default: "reelbase — paste a link, install the video",
    template: "%s · reelbase",
  },
  description:
    "Drop in any video link — YouTube, TikTok, Instagram, Vimeo or a direct MP4 — and reelbase installs a permanent player page for it in your library.",
  applicationName: "reelbase",
  keywords: [
    "video library",
    "youtube link",
    "tiktok link",
    "video bookmark",
    "embed installer",
  ],
};

export const viewport: Viewport = {
  themeColor: "#07070a",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="min-h-screen bg-ink font-sans text-chalk antialiased">
        <div className="aurora" aria-hidden="true" />
        <div className="grid-lines" aria-hidden="true" />
        {children}
      </body>
    </html>
  );
}
