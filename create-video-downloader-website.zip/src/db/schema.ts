import {
  boolean,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  uniqueIndex,
} from "drizzle-orm/pg-core";

/**
 * A single "installed" video. One row per real-world video, deduped on
 * (platform, externalId) so pasting the same link twice refreshes the install
 * instead of creating a duplicate.
 */
export const videos = pgTable(
  "videos",
  {
    id: serial("id").primaryKey(),
    slug: text("slug").notNull().unique(),
    platform: text("platform").notNull(),
    externalId: text("external_id").notNull(),
    url: text("url").notNull(),
    canonicalUrl: text("canonical_url").notNull(),
    title: text("title").notNull(),
    authorName: text("author_name"),
    authorUrl: text("author_url"),
    thumbnailUrl: text("thumbnail_url"),
    embedUrl: text("embed_url"),
    playerKind: text("player_kind").notNull().default("link"),
    note: text("note"),
    favorite: boolean("favorite").notNull().default(false),
    installCount: integer("install_count").notNull().default(1),
    metadataSource: text("metadata_source").notNull().default("derived"),
    metadataCheckedAt: timestamp("metadata_checked_at", { withTimezone: true }),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
  },
  (table) => [
    uniqueIndex("videos_platform_external_idx").on(
      table.platform,
      table.externalId,
    ),
  ],
);

export type VideoRow = typeof videos.$inferSelect;
export type NewVideoRow = typeof videos.$inferInsert;
