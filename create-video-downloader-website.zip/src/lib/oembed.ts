import { normalizeUrl, parseLink } from "./link";
import type { ParsedLink, Platform } from "./types";

type OembedPayload = {
  title?: string;
  author_name?: string;
  author_url?: string;
  thumbnail_url?: string;
  provider_name?: string;
  html?: string;
};

/** Pulls the official iframe src out of an oEmbed html blob, if present. */
function embedFromHtml(html: unknown): string | null {
  if (typeof html !== "string") return null;
  const match = html.match(/src=["']([^"']+)["']/i);
  if (!match?.[1]) return null;
  try {
    const url = new URL(match[1]);
    if (url.protocol !== "https:") return null;
    return url.toString();
  } catch {
    return null;
  }
}

export type ResolvedLink = {
  link: ParsedLink;
  title: string;
  /** true when a live oEmbed lookup produced real title/author data */
  resolved: boolean;
  note: string | null;
};

const SHORT_HOSTS = /(^|\.)(vm|vt)\.tiktok\.com$/i;

async function fetchOembed(endpoint: string): Promise<OembedPayload | null> {
  try {
    const response = await fetch(endpoint, {
      cache: "no-store",
      signal: AbortSignal.timeout(4500),
      headers: {
        accept: "application/json",
        "user-agent":
          "Mozilla/5.0 (compatible; Reelbase/1.0; +https://example.com) AppleWebKit/537.36",
      },
    });
    if (!response.ok) return null;
    const payload = (await response.json()) as OembedPayload;
    if (!payload || typeof payload !== "object") return null;
    return payload;
  } catch {
    return null;
  }
}

/** Follows a handful of redirects so vm.tiktok.com links become real video urls. */
async function followRedirects(rawUrl: string, maxHops = 4): Promise<string> {
  let current = rawUrl;
  for (let hop = 0; hop < maxHops; hop += 1) {
    try {
      const response = await fetch(current, {
        redirect: "manual",
        cache: "no-store",
        signal: AbortSignal.timeout(4500),
        headers: {
          "user-agent":
            "Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.0 Mobile/15E148 Safari/604.1",
        },
      });
      const location = response.headers.get("location");
      if (!location || response.status < 300 || response.status >= 400) {
        return current;
      }
      current = new URL(location, current).toString();
    } catch {
      return current;
    }
  }
  return current;
}

function needsShortResolve(link: ParsedLink): boolean {
  try {
    const url = new URL(link.canonicalUrl);
    return (
      link.platform === "tiktok" &&
      link.externalId.startsWith("short-") &&
      (SHORT_HOSTS.test(url.hostname) || /^\/t\//.test(url.pathname))
    );
  } catch {
    return false;
  }
}

async function resolveShortLink(link: ParsedLink): Promise<ParsedLink> {
  const finalUrl = await followRedirects(link.url);
  if (finalUrl === link.url) return link;
  const reparsed = parseLink(finalUrl);
  if (!reparsed.ok) return link;
  if (reparsed.link.platform !== "tiktok") return link;
  if (reparsed.link.externalId.startsWith("short-")) return link;
  return { ...reparsed.link, url: link.url };
}

function oembedEndpoint(platform: Platform, canonicalUrl: string): string | null {
  const encoded = encodeURIComponent(canonicalUrl);
  switch (platform) {
    case "youtube":
      return `https://www.youtube.com/oembed?url=${encoded}&format=json`;
    case "tiktok":
      return `https://www.tiktok.com/oembed?url=${encoded}`;
    case "vimeo":
      return `https://vimeo.com/api/oembed.json?url=${encoded}`;
    default:
      return null;
  }
}

function cleanText(value: unknown, max = 300): string | null {
  if (typeof value !== "string") return null;
  const trimmed = value.replace(/\s+/g, " ").trim();
  if (!trimmed) return null;
  return trimmed.slice(0, max);
}

/**
 * Resolves a pasted link into a fully described installation.
 * Never throws: if the platform (or the network) blocks us we still install the
 * video with derived metadata and let the embed do the rest.
 */
export async function resolveLink(raw: string): Promise<ResolvedLink> {
  const parsed = parseLink(raw);
  if (!parsed.ok) {
    throw new Error(parsed.error);
  }

  let link = parsed.link;
  let title = parsed.link.suggestedTitle;
  let source: "oembed" | "derived" = "derived";
  let note: string | null = null;

  if (needsShortResolve(link)) {
    link = await resolveShortLink(link);
    if (link.externalId.startsWith("short-")) {
      note = "Short link saved. Open it once to copy the full TikTok url for a player.";
    }
  }

  const endpoint = oembedEndpoint(link.platform, link.canonicalUrl);
  if (endpoint) {
    const payload = await fetchOembed(endpoint);
    if (payload) {
      const fetchedTitle = cleanText(payload.title, 220);
      const author = cleanText(payload.author_name, 120);
      const authorUrl = cleanText(payload.author_url, 400);
      const thumb = cleanText(payload.thumbnail_url, 800);
      const canonical = normalizeUrl(link.canonicalUrl);
      const officialEmbed = embedFromHtml(payload.html);
      title = fetchedTitle ?? title;
      link = {
        ...link,
        authorName: author ?? link.authorName,
        authorUrl: authorUrl ?? link.authorUrl,
        thumbnailUrl: thumb ?? link.thumbnailUrl,
        canonicalUrl: canonical ? canonical.toString() : link.canonicalUrl,
        embedUrl:
          officialEmbed && link.platform === "tiktok" ? officialEmbed : link.embedUrl,
        playerKind: officialEmbed && link.platform === "tiktok" ? "iframe" : link.playerKind,
      };
      source = "oembed";
    } else {
      note =
        link.platform === "youtube"
          ? "YouTube details were unavailable — installed with derived metadata."
          : `${link.platform} details were unavailable — installed with derived metadata.`;
    }
  } else if (link.platform === "instagram") {
    note = "Instagram hides details from servers, so the embed loads the original reel.";
  } else if (link.platform === "twitter") {
    note = "X posts are saved as references; open the original to watch.";
  }

  return { link, title, resolved: source === "oembed", note };
}
