import type {
  ParseResult,
  ParsedLink,
  Platform,
  PlayerKind,
} from "./types";

const VIDEO_FILE = /\.(mp4|webm|ogv|ogg|mov|m4v)$/i;
const YT_ID = /^[A-Za-z0-9_-]{11}$/;
const IG_CODE = /^[A-Za-z0-9_-]{5,}$/;

/** Small deterministic hash so non-video links still get a stable identity. */
export function shortHash(input: string): string {
  let hash = 0x811c9dc5;
  for (let i = 0; i < input.length; i += 1) {
    hash ^= input.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  return (hash >>> 0).toString(36);
}

export function slugify(value: string): string {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 80);
}

export function normalizeUrl(raw: string): URL | null {
  let candidate = raw.trim();
  if (!candidate) return null;
  if (candidate.startsWith("//")) candidate = `https:${candidate}`;
  if (!/^[a-z][a-z0-9+.-]*:/i.test(candidate)) candidate = `https://${candidate}`;

  try {
    const url = new URL(candidate);
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    if (!url.hostname.includes(".")) return null;
    return url;
  } catch {
    return null;
  }
}

function youtubeId(url: URL): string | null {
  const host = url.hostname.replace(/^www\./, "");
  if (host === "youtu.be") {
    return url.pathname.split("/").filter(Boolean)[0] ?? null;
  }
  const param = url.searchParams.get("v");
  if (param && YT_ID.test(param)) return param;

  const segments = url.pathname.split("/").filter(Boolean);
  const keyed = ["shorts", "embed", "live", "v", "e"];
  if (segments.length >= 2 && keyed.includes(segments[0]!)) {
    return segments[1] ?? null;
  }
  return null;
}

function parseYoutube(url: URL, original: string): ParseResult {
  const id = youtubeId(url);
  if (!id || !YT_ID.test(id)) {
    return {
      ok: false,
      error:
        "That YouTube link does not contain a video id. Try a watch, Shorts or youtu.be link.",
    };
  }
  const link: ParsedLink = {
    platform: "youtube",
    externalId: id,
    url: original,
    canonicalUrl: `https://www.youtube.com/watch?v=${id}`,
    embedUrl: `https://www.youtube-nocookie.com/embed/${id}?rel=0&modestbranding=1&playsinline=1`,
    thumbnailUrl: `https://i.ytimg.com/vi/${id}/hqdefault.jpg`,
    playerKind: "iframe",
    suggestedTitle: "YouTube video",
    authorName: null,
    authorUrl: null,
  };
  return { ok: true, link };
}

function parseTiktok(url: URL, original: string): ParseResult {
  const segments = url.pathname.split("/").filter(Boolean);
  const videoIndex = segments.indexOf("video");
  const numericId =
    videoIndex >= 0 ? /^\d{6,}$/.test(segments[videoIndex + 1] ?? "") : false;
  const id = numericId ? segments[videoIndex + 1]! : null;
  const handle = segments[0]?.startsWith("@")
    ? segments[0].slice(1)
    : segments[0] === "t" && segments[1]
      ? null
      : null;

  if (id) {
    const link: ParsedLink = {
      platform: "tiktok",
      externalId: id,
      url: original,
      canonicalUrl: handle
        ? `https://www.tiktok.com/@${handle}/video/${id}`
        : `https://www.tiktok.com/@/video/${id}`,
      embedUrl: `https://www.tiktok.com/player/v1/${id}?autoplay=0&loop=0&music_info=1&description=1`,
      thumbnailUrl: null,
      playerKind: "iframe",
      suggestedTitle: "TikTok video",
      authorName: handle,
      authorUrl: handle ? `https://www.tiktok.com/@${handle}` : null,
    };
    return { ok: true, link };
  }

  // Short links (vm.tiktok.com/XXXX, tiktok.com/t/XXXX) get resolved later.
  const code = segments[segments.length - 1] ?? "";
  if (!code) {
    return {
      ok: false,
      error: "That TikTok link is missing a video id or short code.",
    };
  }
  const link: ParsedLink = {
    platform: "tiktok",
    externalId: `short-${shortHash(url.toString())}`,
    url: original,
    canonicalUrl: url.toString(),
    embedUrl: null,
    thumbnailUrl: null,
    playerKind: "link",
    suggestedTitle: "TikTok link",
    authorName: null,
    authorUrl: null,
  };
  return { ok: true, link };
}

function parseInstagram(url: URL, original: string): ParseResult {
  const segments = url.pathname.split("/").filter(Boolean);
  const kind = ["reel", "reels", "p", "tv"].includes(segments[0] ?? "")
    ? segments[0]!
    : "p";
  const code = segments[1] ?? "";
  if (!IG_CODE.test(code)) {
    return {
      ok: false,
      error: "That Instagram link does not contain a reel or post code.",
    };
  }
  const normalised = kind === "reels" ? "reel" : kind;
  const link: ParsedLink = {
    platform: "instagram",
    externalId: code,
    url: original,
    canonicalUrl: `https://www.instagram.com/${normalised}/${code}/`,
    embedUrl: `https://www.instagram.com/${normalised}/${code}/embed/`,
    thumbnailUrl: null,
    playerKind: "iframe",
    suggestedTitle: "Instagram reel",
    authorName: null,
    authorUrl: null,
  };
  return { ok: true, link };
}

function parseVimeo(url: URL, original: string): ParseResult {
  const segments = url.pathname.split("/").filter(Boolean);
  const idMatch =
    [...segments].reverse().find((part) => /^\d{5,}$/.test(part)) ?? null;
  if (!idMatch) {
    return {
      ok: false,
      error: "That Vimeo link does not contain a numeric video id.",
    };
  }
  const link: ParsedLink = {
    platform: "vimeo",
    externalId: idMatch,
    url: original,
    canonicalUrl: `https://vimeo.com/${idMatch}`,
    embedUrl: `https://player.vimeo.com/video/${idMatch}?dnt=1`,
    thumbnailUrl: null,
    playerKind: "iframe",
    suggestedTitle: "Vimeo video",
    authorName: null,
    authorUrl: null,
  };
  return { ok: true, link };
}

function parseTwitter(url: URL, original: string): ParseResult {
  const segments = url.pathname.split("/").filter(Boolean);
  const statusIndex = segments.findIndex((part) => part === "status");
  const id =
    statusIndex >= 0 ? (segments[statusIndex + 1] ?? null) : null;
  if (!id || !/^\d+$/.test(id)) {
    return {
      ok: false,
      error: "That X link does not point at a specific post.",
    };
  }
  const link: ParsedLink = {
    platform: "twitter",
    externalId: id,
    url: original,
    canonicalUrl: `https://x.com/i/status/${id}`,
    embedUrl: null,
    thumbnailUrl: null,
    playerKind: "link",
    suggestedTitle: "Post on X",
    authorName: segments[0] ?? null,
    authorUrl: segments[0] ? `https://x.com/${segments[0]}` : null,
  };
  return { ok: true, link };
}

function parseFile(url: URL, original: string): ParseResult {
  const name = decodeURIComponent(url.pathname.split("/").filter(Boolean).pop() ?? "video");
  const stem = name.replace(VIDEO_FILE, "").replace(/[._-]+/g, " ").trim();
  const identity = `${url.origin}${url.pathname}`;
  const link: ParsedLink = {
    platform: "file",
    externalId: shortHash(identity),
    url: original,
    canonicalUrl: url.toString(),
    embedUrl: url.toString(),
    thumbnailUrl: null,
    playerKind: "video",
    suggestedTitle: stem ? stem.replace(/\b\w/g, (c) => c.toUpperCase()) : "Direct video file",
    authorName: url.hostname.replace(/^www\./, ""),
    authorUrl: `${url.protocol}//${url.hostname}`,
  };
  return { ok: true, link };
}

function parseWeb(url: URL, original: string): ParseResult {
  const path = url.pathname === "/" ? "" : url.pathname;
  const link: ParsedLink = {
    platform: "web",
    externalId: `web-${shortHash(`${url.origin}${url.pathname}${url.search}`)}`,
    url: original,
    canonicalUrl: url.toString(),
    embedUrl: null,
    thumbnailUrl: null,
    playerKind: "link",
    suggestedTitle: `${url.hostname.replace(/^www\./, "")}${path}`,
    authorName: null,
    authorUrl: null,
  };
  return { ok: true, link };
}

/**
 * Turns any pasted string into a player-ready installation descriptor.
 * Pure + synchronous so the client can preview detection as you type.
 */
export function parseLink(raw: string): ParseResult {
  const url = normalizeUrl(raw);
  if (!url) {
    return { ok: false, error: "Paste a full link, e.g. https://youtu.be/dQw4w9WgXcQ" };
  }

  const host = url.hostname.replace(/^www\./, "");
  const platform: Platform = host === "youtu.be" || host.endsWith("youtube.com") ||
    host.endsWith("youtube-nocookie.com")
    ? "youtube"
    : host.endsWith("tiktok.com")
      ? "tiktok"
      : host.endsWith("instagram.com")
        ? "instagram"
        : host.endsWith("vimeo.com")
          ? "vimeo"
          : host === "x.com" || host.endsWith("twitter.com")
            ? "twitter"
            : VIDEO_FILE.test(url.pathname)
              ? "file"
              : "web";

  const original = raw.trim();

  switch (platform) {
    case "youtube":
      return parseYoutube(url, original);
    case "tiktok":
      return parseTiktok(url, original);
    case "instagram":
      return parseInstagram(url, original);
    case "vimeo":
      return parseVimeo(url, original);
    case "twitter":
      return parseTwitter(url, original);
    case "file":
      return parseFile(url, original);
    default:
      return parseWeb(url, original);
  }
}

/** Snapshot used on the client while somebody is still typing. */
export type LinkPreview = {
  platform: Platform;
  title: string;
  thumbnailUrl: string | null;
  playerKind: PlayerKind;
  externalId: string;
};

export function previewLink(raw: string): LinkPreview | null {
  const parsed = parseLink(raw);
  if (!parsed.ok) return null;
  return {
    platform: parsed.link.platform,
    title: parsed.link.suggestedTitle,
    thumbnailUrl: parsed.link.thumbnailUrl,
    playerKind: parsed.link.playerKind,
    externalId: parsed.link.externalId,
  };
}
