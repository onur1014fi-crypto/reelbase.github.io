export type Platform =
  | "youtube"
  | "tiktok"
  | "instagram"
  | "vimeo"
  | "twitter"
  | "file"
  | "web";

export type PlayerKind = "iframe" | "video" | "link";

export type PlatformMeta = {
  label: string;
  shortLabel: string;
  accent: string;
  tint: string;
  description: string;
};

export const PLATFORM_META: Record<Platform, PlatformMeta> = {
  youtube: {
    label: "YouTube",
    shortLabel: "YT",
    accent: "#ff4d4d",
    tint: "rgba(255, 77, 77, 0.14)",
    description: "Watch page, Shorts, youtu.be, live and embed links",
  },
  tiktok: {
    label: "TikTok",
    shortLabel: "TT",
    accent: "#25f4ee",
    tint: "rgba(37, 244, 238, 0.12)",
    description: "Full video URLs plus vm.tiktok.com short links",
  },
  instagram: {
    label: "Instagram",
    shortLabel: "IG",
    accent: "#f260b4",
    tint: "rgba(242, 96, 180, 0.14)",
    description: "Reels, posts and IGTV links",
  },
  vimeo: {
    label: "Vimeo",
    shortLabel: "VM",
    accent: "#5ec6ff",
    tint: "rgba(94, 198, 255, 0.14)",
    description: "Standard video and channel links",
  },
  twitter: {
    label: "X / Twitter",
    shortLabel: "X",
    accent: "#cfd3dc",
    tint: "rgba(207, 211, 220, 0.12)",
    description: "Post links are saved as outbound references",
  },
  file: {
    label: "Direct file",
    shortLabel: "MP4",
    accent: "#d8ff4a",
    tint: "rgba(216, 255, 74, 0.14)",
    description: "MP4, WebM, Ogg and MOV files play natively",
  },
  web: {
    label: "Web link",
    shortLabel: "WEB",
    accent: "#9a8cff",
    tint: "rgba(154, 140, 255, 0.14)",
    description: "Saved as a reference when no player is available",
  },
};

export type ParsedLink = {
  platform: Platform;
  externalId: string;
  url: string;
  canonicalUrl: string;
  embedUrl: string | null;
  thumbnailUrl: string | null;
  playerKind: PlayerKind;
  suggestedTitle: string;
  authorName: string | null;
  authorUrl: string | null;
};

export type ParseResult =
  | { ok: true; link: ParsedLink }
  | { ok: false; error: string };

export type VideoDTO = {
  id: number;
  slug: string;
  platform: Platform;
  externalId: string;
  url: string;
  canonicalUrl: string;
  title: string;
  authorName: string | null;
  authorUrl: string | null;
  thumbnailUrl: string | null;
  embedUrl: string | null;
  playerKind: PlayerKind;
  note: string | null;
  favorite: boolean;
  installCount: number;
  metadataSource: string;
  createdAt: string;
  updatedAt: string;
};

export type InstallResponse = {
  ok: true;
  created: boolean;
  resolved: boolean;
  video: VideoDTO;
};
