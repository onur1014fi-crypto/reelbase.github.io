import { and, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { videos, type VideoRow } from "@/db/schema";
import { parseLink, slugify } from "./link";
import { resolveLink } from "./oembed";
import type { Platform, PlayerKind, VideoDTO } from "./types";

export function toDTO(row: VideoRow): VideoDTO {
  return {
    id: row.id,
    slug: row.slug,
    platform: row.platform as Platform,
    externalId: row.externalId,
    url: row.url,
    canonicalUrl: row.canonicalUrl,
    title: row.title,
    authorName: row.authorName,
    authorUrl: row.authorUrl,
    thumbnailUrl: row.thumbnailUrl,
    embedUrl: row.embedUrl,
    playerKind: row.playerKind as PlayerKind,
    note: row.note,
    favorite: row.favorite,
    installCount: row.installCount,
    metadataSource: row.metadataSource,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function listVideos(): Promise<VideoDTO[]> {
  const rows = await db.select().from(videos).orderBy(desc(videos.createdAt), desc(videos.id));
  return rows.map(toDTO);
}

export async function getVideoBySlug(slug: string): Promise<VideoDTO | null> {
  const rows = await db.select().from(videos).where(eq(videos.slug, slug)).limit(1);
  return rows[0] ? toDTO(rows[0]) : null;
}

export async function getVideoById(id: number): Promise<VideoDTO | null> {
  const rows = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  return rows[0] ? toDTO(rows[0]) : null;
}

export type InstallResult = {
  video: VideoDTO;
  created: boolean;
  resolved: boolean;
  note: string | null;
};

/**
 * The core "install" operation: resolve the link, then upsert a single row for
 * that video so repeated pastes refresh an install instead of duplicating it.
 */
export async function installFromUrl(raw: string): Promise<InstallResult> {
  const resolved = await resolveLink(raw);
  const { link, title } = resolved;
  const slug = slugify(`${link.platform}-${link.externalId}`) || `link-${Date.now()}`;
  const now = new Date();

  const existing = await db
    .select()
    .from(videos)
    .where(and(eq(videos.platform, link.platform), eq(videos.externalId, link.externalId)))
    .limit(1);

  if (existing[0]) {
    const updated = await db
      .update(videos)
      .set({
        url: link.url,
        canonicalUrl: link.canonicalUrl,
        title: resolved.resolved ? title : existing[0].title,
        authorName: link.authorName ?? existing[0].authorName,
        authorUrl: link.authorUrl ?? existing[0].authorUrl,
        thumbnailUrl: link.thumbnailUrl ?? existing[0].thumbnailUrl,
        embedUrl: link.embedUrl ?? existing[0].embedUrl,
        playerKind: link.playerKind,
        installCount: existing[0].installCount + 1,
        metadataSource: resolved.resolved ? "oembed" : existing[0].metadataSource,
        metadataCheckedAt: resolved.resolved ? now : existing[0].metadataCheckedAt,
        updatedAt: now,
      })
      .where(eq(videos.id, existing[0].id))
      .returning();

    return {
      video: toDTO(updated[0] ?? existing[0]),
      created: false,
      resolved: resolved.resolved,
      note: resolved.note,
    };
  }

  const inserted = await db
    .insert(videos)
    .values({
      slug,
      platform: link.platform,
      externalId: link.externalId,
      url: link.url,
      canonicalUrl: link.canonicalUrl,
      title,
      authorName: link.authorName,
      authorUrl: link.authorUrl,
      thumbnailUrl: link.thumbnailUrl,
      embedUrl: link.embedUrl,
      playerKind: link.playerKind,
      installCount: 1,
      metadataSource: resolved.resolved ? "oembed" : "derived",
      metadataCheckedAt: resolved.resolved ? now : null,
    })
    .onConflictDoNothing({ target: [videos.platform, videos.externalId] })
    .returning();

  if (inserted[0]) {
    return {
      video: toDTO(inserted[0]),
      created: true,
      resolved: resolved.resolved,
      note: resolved.note,
    };
  }

  // Lost a race with another install of the same video — update that row.
  const raced = await db
    .select()
    .from(videos)
    .where(and(eq(videos.platform, link.platform), eq(videos.externalId, link.externalId)))
    .limit(1);

  if (!raced[0]) {
    throw new Error("Could not install this link. Please try again.");
  }

  return {
    video: toDTO(raced[0]),
    created: false,
    resolved: resolved.resolved,
    note: resolved.note,
  };
}

export async function updateVideoById(
  id: number,
  patch: { favorite?: boolean; note?: string | null; title?: string },
): Promise<VideoDTO | null> {
  const values: Partial<VideoRow> = { updatedAt: new Date() };
  if (typeof patch.favorite === "boolean") values.favorite = patch.favorite;
  if (patch.note !== undefined) values.note = patch.note ? patch.note.slice(0, 600) : null;
  if (patch.title && patch.title.trim()) values.title = patch.title.trim().slice(0, 220);

  const updated = await db.update(videos).set(values).where(eq(videos.id, id)).returning();
  return updated[0] ? toDTO(updated[0]) : null;
}

export async function refreshVideoById(id: number): Promise<InstallResult | null> {
  const rows = await db.select().from(videos).where(eq(videos.id, id)).limit(1);
  if (!rows[0]) return null;
  return installFromUrl(rows[0].canonicalUrl);
}

export async function deleteVideoById(id: number): Promise<boolean> {
  const deleted = await db.delete(videos).where(eq(videos.id, id)).returning({ id: videos.id });
  return deleted.length > 0;
}

type Seed = {
  url: string;
  title: string;
  authorName: string;
  authorUrl: string;
  note: string | null;
  favorite?: boolean;
  hoursAgo: number;
};

const SEEDS: Seed[] = [
  {
    url: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    title: "Rick Astley - Never Gonna Give You Up (Official Video)",
    authorName: "Rick Astley",
    authorUrl: "https://www.youtube.com/@RickAstleyYT",
    favorite: true,
    note: "The benchmark link. If this one installs, everything works.",
    hoursAgo: 1,
  },
  {
    url: "https://www.youtube.com/watch?v=LXb3EKWsInQ",
    title: "COSTA RICA IN 4K 60fps HDR (ULTRA HD)",
    authorName: "Jacob + Katie Schwarz",
    authorUrl: "https://www.youtube.com/@JacobKatieSchwarz",
    note: "The clip I use to check player colour and quality.",
    hoursAgo: 9,
  },
  {
    url: "https://www.tiktok.com/@scout2015/video/6718335390845095173",
    title: "TikTok sample clip — @scout2015",
    authorName: "scout2015",
    authorUrl: "https://www.tiktok.com/@scout2015",
    note: "Vertical installs get a 9:16 player. TikTok only returns a player from its oEmbed endpoint, so this entry uses the generated fallback artwork.",
    hoursAgo: 26,
  },
  {
    url: "https://vimeo.com/76979871",
    title: "The New Vimeo Player (You Know, For Videos)",
    authorName: "Vimeo",
    authorUrl: "https://vimeo.com/vimeo",
    note: null,
    hoursAgo: 52,
  },
  {
    url: "https://www.youtube.com/watch?v=jNQXAC9IVRw",
    title: "Me at the zoo",
    authorName: "jawed",
    authorUrl: "https://www.youtube.com/@jawed",
    favorite: true,
    note: "First video ever uploaded to YouTube. Archived here forever.",
    hoursAgo: 96,
  },
  {
    url: "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
    title: "Big Buck Bunny — 10s sample (MP4)",
    authorName: "test-videos.co.uk",
    authorUrl: "https://test-videos.co.uk",
    note: "Direct MP4 links stream through the proxy with seeking, and can be downloaded from this page.",
    hoursAgo: 140,
  },
];

/**
 * Keeps a fresh database from looking broken. Only runs when the library is
 * completely empty, so real installs are never touched.
 */
export async function ensureSeeded(): Promise<void> {
  const [{ value }] = await db
    .select({ value: sql<number>`count(*)::int` })
    .from(videos);
  if (value > 0) return;

  const rows = SEEDS.flatMap((seed) => {
    const parsed = parseLink(seed.url);
    if (!parsed.ok) return [];
    const createdAt = new Date(Date.now() - seed.hoursAgo * 3600_000);
    return [
      {
        slug: slugify(`${parsed.link.platform}-${parsed.link.externalId}`),
        platform: parsed.link.platform,
        externalId: parsed.link.externalId,
        url: parsed.link.url,
        canonicalUrl: parsed.link.canonicalUrl,
        title: seed.title,
        authorName: seed.authorName,
        authorUrl: seed.authorUrl,
        thumbnailUrl: parsed.link.thumbnailUrl,
        embedUrl: parsed.link.embedUrl,
        playerKind: parsed.link.playerKind,
        note: seed.note,
        favorite: seed.favorite ?? false,
        installCount: 1,
        metadataSource: "curated",
        createdAt,
        updatedAt: createdAt,
      },
    ];
  });

  if (rows.length === 0) return;
  await db.insert(videos).values(rows).onConflictDoNothing();
}
