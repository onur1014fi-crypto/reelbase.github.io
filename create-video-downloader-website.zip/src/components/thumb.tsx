"use client";

import { useState } from "react";
import { PLATFORM_META, type Platform } from "@/lib/types";
import { PlatformIcon } from "./icons";

type ThumbProps = {
  src: string | null;
  alt: string;
  platform: Platform;
  title: string;
  className?: string;
  compact?: boolean;
};

/**
 * Remote thumbnails fail often (CDN hotlink rules, offline previews), so every
 * thumbnail has a designed fallback built from the platform identity.
 */
export function Thumb({ src, alt, platform, title, className = "", compact = false }: ThumbProps) {
  const [failedSrc, setFailedSrc] = useState<string | null>(null);
  const meta = PLATFORM_META[platform];
  // Deriving failure from the current src means a new url automatically retries.
  const failed = Boolean(src) && failedSrc === src;
  const showImage = Boolean(src) && !failed;

  return (
    <div className={`relative overflow-hidden bg-[#0b0b10] ${className}`}>
      {showImage ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={src ?? ""}
          alt={alt}
          loading="lazy"
          decoding="async"
          referrerPolicy="no-referrer"
          onError={() => setFailedSrc(src ?? null)}
          className="h-full w-full object-cover transition duration-500 group-hover:scale-[1.03]"
        />
      ) : (
        <div className="absolute inset-0">
          <div
            className="absolute inset-0"
            style={{
              background: `radial-gradient(120% 120% at 15% 0%, ${meta.tint}, #0c0c12 58%, #08080b 100%)`,
            }}
          />
          <div
            className="absolute inset-0 opacity-[0.18]"
            style={{
              backgroundImage:
                "repeating-linear-gradient(118deg, rgba(255,255,255,0.55) 0 1px, transparent 1px 16px)",
              maskImage: "radial-gradient(90% 90% at 80% 10%, black, transparent)",
            }}
          />
          <div className={`relative flex h-full flex-col justify-between ${compact ? "p-3" : "p-4"}`}>
            <PlatformIcon
              platform={platform}
              className={compact ? "h-5 w-5" : "h-6 w-6"}
              style={{ color: meta.accent }}
            />
            {!compact && (
              <p className="line-clamp-2 pr-6 text-[13px] font-semibold leading-snug text-white/85">
                {title}
              </p>
            )}
            <p className="font-mono text-[9px] uppercase tracking-[0.22em] text-white/40">
              {meta.label} · no thumbnail
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
