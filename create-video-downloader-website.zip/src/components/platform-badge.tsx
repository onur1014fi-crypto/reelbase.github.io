import { PLATFORM_META, type Platform } from "@/lib/types";
import { PlatformIcon } from "./icons";

export function PlatformBadge({
  platform,
  size = "sm",
  showIcon = true,
}: {
  platform: Platform;
  size?: "sm" | "md";
  showIcon?: boolean;
}) {
  const meta = PLATFORM_META[platform];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-black/55 font-mono uppercase tracking-[0.14em] backdrop-blur ${
        size === "sm" ? "px-2 py-1 text-[9px]" : "px-2.5 py-1.5 text-[10px]"
      }`}
      style={{ color: meta.accent }}
    >
      {showIcon && (
        <PlatformIcon platform={platform} className={size === "sm" ? "h-3 w-3" : "h-3.5 w-3.5"} />
      )}
      {meta.label}
    </span>
  );
}
