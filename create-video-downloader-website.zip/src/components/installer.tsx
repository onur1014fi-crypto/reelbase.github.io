"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useMemo, useRef, useState } from "react";
import { parseLink } from "@/lib/link";
import { PLATFORM_META, type VideoDTO } from "@/lib/types";
import {
  ArrowRightIcon,
  CheckIcon,
  ClipboardIcon,
  LinkIcon,
  PlatformIcon,
  SpinnerIcon,
  XIcon,
} from "./icons";
import { Thumb } from "./thumb";

type Feedback = {
  kind: "ok" | "error" | "info";
  message: string;
  href?: string;
};

const EXAMPLES = [
  { label: "YouTube", value: "https://www.youtube.com/watch?v=dQw4w9WgXcQ" },
  { label: "TikTok", value: "https://www.tiktok.com/@tiktok/video/6718335390845095173" },
  { label: "Vimeo", value: "https://vimeo.com/76979871" },
  {
    label: "MP4",
    value:
      "https://test-videos.co.uk/vids/bigbuckbunny/mp4/h264/720/Big_Buck_Bunny_720_10s_1MB.mp4",
  },
];

export function Installer() {
  const router = useRouter();
  const inputRef = useRef<HTMLInputElement>(null);
  const [value, setValue] = useState("");
  const [busy, setBusy] = useState(false);
  const [feedback, setFeedback] = useState<Feedback | null>(null);

  const detection = useMemo(() => (value.trim() ? parseLink(value) : null), [value]);
  const preview = detection?.ok ? detection.link : null;
  const platformMeta = preview ? PLATFORM_META[preview.platform] : null;

  async function install(raw: string) {
    if (busy) return;
    const trimmed = raw.trim();
    if (!trimmed) {
      setFeedback({ kind: "error", message: "Paste a video link first." });
      inputRef.current?.focus();
      return;
    }

    setBusy(true);
    setFeedback(null);

    try {
      const response = await fetch("/api/videos", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ url: trimmed }),
      });
      const data = (await response.json()) as {
        ok?: boolean;
        error?: string;
        created?: boolean;
        note?: string | null;
        video?: VideoDTO;
      };

      if (!response.ok || !data.ok || !data.video) {
        setFeedback({
          kind: "error",
          message: data.error ?? "That link could not be installed.",
        });
        return;
      }

      setValue("");
      setFeedback({
        kind: "ok",
        message: data.created
          ? `Installed “${data.video.title}”`
          : `Already in your library — “${data.video.title}” was re-synced.`,
        href: `/v/${data.video.slug}`,
      });
      router.refresh();
    } catch {
      setFeedback({
        kind: "error",
        message: "Network hiccup — the link was not installed. Try again.",
      });
    } finally {
      setBusy(false);
    }
  }

  async function pasteFromClipboard() {
    try {
      const text = await navigator.clipboard.readText();
      if (!text.trim()) {
        setFeedback({ kind: "info", message: "Your clipboard is empty." });
        return;
      }
      setValue(text.trim());
      setFeedback(null);
      inputRef.current?.focus();
    } catch {
      setFeedback({
        kind: "info",
        message: "Clipboard blocked by the browser — paste with ⌘V / Ctrl+V.",
      });
      inputRef.current?.focus();
    }
  }

  return (
    <div id="install" className="scroll-mt-24">
      <div className="installer-glow rounded-[24px] p-[1px]">
        <div className="rounded-[23px] bg-[#0c0c11]/95 p-2.5 sm:p-3">
          <form
            onSubmit={(event) => {
              event.preventDefault();
              void install(value);
            }}
            className="flex flex-col gap-2.5 sm:flex-row sm:items-center"
          >
            <div className="flex min-w-0 flex-1 items-center gap-3 rounded-[16px] border border-white/[0.07] bg-black/45 px-4">
              <LinkIcon className="h-[18px] w-[18px] shrink-0 text-white/35" />
              <input
                ref={inputRef}
                value={value}
                onChange={(event) => {
                  setValue(event.target.value);
                  if (feedback?.kind === "error") setFeedback(null);
                }}
                placeholder="Paste any video link — youtube.com, tiktok.com, vimeo.com, .mp4…"
                aria-label="Video link"
                spellCheck={false}
                autoComplete="off"
                className="w-full min-w-0 bg-transparent py-4 text-[14.5px] text-chalk outline-none placeholder:text-white/30"
              />
              {value ? (
                <button
                  type="button"
                  onClick={() => {
                    setValue("");
                    setFeedback(null);
                    inputRef.current?.focus();
                  }}
                  aria-label="Clear link"
                  className="shrink-0 rounded-full p-1 text-white/35 transition hover:text-white"
                >
                  <XIcon className="h-4 w-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={() => void pasteFromClipboard()}
                  className="shrink-0 rounded-full border border-white/10 px-2.5 py-1 font-mono text-[10px] uppercase tracking-[0.12em] text-white/45 transition hover:border-lime/40 hover:text-lime"
                >
                  paste
                </button>
              )}
            </div>

            <button
              type="submit"
              disabled={busy}
              className="inline-flex h-[52px] shrink-0 items-center justify-center gap-2 rounded-[16px] bg-lime px-6 text-[14px] font-semibold text-black transition hover:bg-[#e8ff83] disabled:cursor-not-allowed disabled:opacity-70"
            >
              {busy ? (
                <>
                  <SpinnerIcon className="h-4 w-4" />
                  Installing…
                </>
              ) : (
                <>
                  Install video
                  <ArrowRightIcon className="h-4 w-4" />
                </>
              )}
            </button>
          </form>

          <div className="mt-2.5 px-1.5 pb-0.5">
            {preview && platformMeta ? (
              <div className="flex items-center justify-between gap-3 rounded-xl border border-white/[0.06] bg-white/[0.02] px-2.5 py-2">
                <div className="flex min-w-0 items-center gap-2.5">
                  {preview.thumbnailUrl ? (
                    <Thumb
                      src={preview.thumbnailUrl}
                      alt=""
                      platform={preview.platform}
                      title={preview.suggestedTitle}
                      compact
                      className="h-9 w-14 shrink-0 rounded-md"
                    />
                  ) : (
                    <span
                      className="grid h-9 w-9 shrink-0 place-items-center rounded-md border border-white/10"
                      style={{ background: platformMeta.tint, color: platformMeta.accent }}
                    >
                      <PlatformIcon platform={preview.platform} className="h-4 w-4" />
                    </span>
                  )}
                  <div className="min-w-0">
                    <p className="truncate text-[12.5px] font-medium text-chalk/90">
                      {preview.authorName ? `${preview.authorName} · ` : ""}
                      {preview.suggestedTitle}
                    </p>
                    <p className="truncate font-mono text-[9.5px] uppercase tracking-[0.16em] text-white/35">
                      {platformMeta.label} detected ·{" "}
                      {preview.playerKind === "link" ? "saved as reference" : "player ready"}
                    </p>
                  </div>
                </div>
                <span className="hidden shrink-0 items-center gap-1 rounded-full border border-lime/30 bg-lime/10 px-2 py-1 font-mono text-[9px] uppercase tracking-[0.14em] text-lime sm:inline-flex">
                  <CheckIcon className="h-3 w-3" /> ready
                </span>
              </div>
            ) : value.trim() ? (
              <p className="px-1 py-1.5 text-[12px] text-white/40">
                {detection && !detection.ok
                  ? detection.error
                  : "Checking that link…"}
              </p>
            ) : (
              <div className="flex flex-wrap items-center gap-1.5 px-0.5 py-1">
                <span className="mr-1 font-mono text-[9.5px] uppercase tracking-[0.16em] text-white/30">
                  try
                </span>
                {EXAMPLES.map((example) => (
                  <button
                    key={example.label}
                    type="button"
                    onClick={() => {
                      setValue(example.value);
                      setFeedback(null);
                      inputRef.current?.focus();
                    }}
                    className="rounded-full border border-white/[0.08] px-2.5 py-1 text-[11px] text-fog transition hover:border-white/25 hover:text-chalk"
                  >
                    {example.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      <div aria-live="polite" className="min-h-[30px]">
        {feedback && (
          <div
            className={`mt-3 flex flex-wrap items-center gap-x-2 gap-y-1 rounded-xl border px-3 py-2 text-[12.5px] ${
              feedback.kind === "ok"
                ? "border-lime/25 bg-lime/[0.07] text-lime"
                : feedback.kind === "error"
                  ? "border-red-400/25 bg-red-400/[0.07] text-red-300"
                  : "border-white/10 bg-white/[0.03] text-fog"
            }`}
          >
            <span className="min-w-0 flex-1">{feedback.message}</span>
            {feedback.href && (
              <Link
                href={feedback.href}
                className="inline-flex shrink-0 items-center gap-1 font-semibold underline decoration-lime/40 underline-offset-4"
              >
                Open install <ArrowRightIcon className="h-3.5 w-3.5" />
              </Link>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
