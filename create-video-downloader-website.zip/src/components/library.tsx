"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { hostOf, timeAgo } from "@/lib/format";
import { PLATFORM_META, type Platform, type VideoDTO } from "@/lib/types";
import {
  FilmIcon,
  LinkIcon,
  PlayIcon,
  SearchIcon,
  SparkIcon,
  StarIcon,
} from "./icons";
import { PlatformBadge } from "./platform-badge";
import { Thumb } from "./thumb";

type SortKey = "recent" | "oldest" | "title" | "installs";

const SORTS: { key: SortKey; label: string }[] = [
  { key: "recent", label: "Newest first" },
  { key: "oldest", label: "Oldest first" },
  { key: "title", label: "Title A–Z" },
  { key: "installs", label: "Most installed" },
];

function matches(video: VideoDTO, query: string): boolean {
  if (!query) return true;
  const haystack = [
    video.title,
    video.authorName ?? "",
    video.note ?? "",
    video.canonicalUrl,
    PLATFORM_META[video.platform].label,
  ]
    .join(" ")
    .toLowerCase();
  return query
    .toLowerCase()
    .split(/\s+/)
    .filter(Boolean)
    .every((token) => haystack.includes(token));
}

export function Library({ initialVideos }: { initialVideos: VideoDTO[] }) {
  const [videos, setVideos] = useState<VideoDTO[]>(initialVideos);
  const [query, setQuery] = useState("");
  const [platform, setPlatform] = useState<Platform | "all">("all");
  const [favoritesOnly, setFavoritesOnly] = useState(false);
  const [sort, setSort] = useState<SortKey>("recent");
  const [message, setMessage] = useState<string | null>(null);

  const signature = useMemo(
    () =>
      initialVideos
        .map((video) => `${video.id}:${video.updatedAt}:${video.favorite}:${video.title}`)
        .join("|"),
    [initialVideos],
  );

  useEffect(() => {
    setVideos(initialVideos);
  }, [signature, initialVideos]);

  const platforms = useMemo(() => {
    const counts = new Map<Platform, number>();
    for (const video of videos) {
      counts.set(video.platform, (counts.get(video.platform) ?? 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]);
  }, [videos]);

  const filtered = useMemo(() => {
    const list = videos.filter((video) => {
      if (platform !== "all" && video.platform !== platform) return false;
      if (favoritesOnly && !video.favorite) return false;
      return matches(video, query);
    });

    return list.sort((a, b) => {
      switch (sort) {
        case "oldest":
          return new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime();
        case "title":
          return a.title.localeCompare(b.title);
        case "installs":
          return b.installCount - a.installCount;
        default:
          return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      }
    });
  }, [videos, platform, favoritesOnly, query, sort]);

  async function toggleFavorite(video: VideoDTO) {
    const next = !video.favorite;
    setVideos((current) =>
      current.map((item) => (item.id === video.id ? { ...item, favorite: next } : item)),
    );
    setMessage(next ? "Saved to favourites." : "Removed from favourites.");
    try {
      const response = await fetch(`/api/videos/${video.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ favorite: next }),
      });
      if (!response.ok) throw new Error("failed");
    } catch {
      setVideos((current) =>
        current.map((item) =>
          item.id === video.id ? { ...item, favorite: video.favorite } : item,
        ),
      );
      setMessage("Could not save that favourite — try again.");
    }
  }

  useEffect(() => {
    if (!message) return;
    const timer = window.setTimeout(() => setMessage(null), 2600);
    return () => window.clearTimeout(timer);
  }, [message]);

  const resetFilters = () => {
    setQuery("");
    setPlatform("all");
    setFavoritesOnly(false);
    setSort("recent");
  };

  return (
    <div>
      <div className="flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 font-mono text-[10px] uppercase tracking-[0.22em] text-white/35">
            <FilmIcon className="h-3.5 w-3.5" /> the collection
          </div>
          <h2 className="mt-2 text-[26px] font-semibold tracking-[-0.03em] text-chalk sm:text-[30px]">
            Your library
          </h2>
        </div>
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-white/35">
          {videos.length} installed · {platforms.length} platform{platforms.length === 1 ? "" : "s"} ·{" "}
          {videos.filter((video) => video.favorite).length} starred
        </p>
      </div>

      <div className="mt-5 flex flex-col gap-3">
        <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
          <label className="flex flex-1 items-center gap-2.5 rounded-xl border border-white/[0.08] bg-panel/70 px-3.5 py-2.5 transition focus-within:border-lime/40">
            <SearchIcon className="h-4 w-4 shrink-0 text-white/30" />
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search titles, creators, notes…"
              className="w-full bg-transparent text-[13px] text-chalk outline-none placeholder:text-white/30"
            />
            {query && (
              <button
                type="button"
                onClick={() => setQuery("")}
                className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/35 hover:text-white"
              >
                clear
              </button>
            )}
          </label>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setFavoritesOnly((current) => !current)}
              className={`inline-flex items-center gap-1.5 rounded-xl border px-3 py-2.5 text-[12px] transition ${
                favoritesOnly
                  ? "border-lime/40 bg-lime/10 text-lime"
                  : "border-white/[0.08] bg-panel/70 text-fog hover:text-chalk"
              }`}
            >
              <StarIcon className="h-3.5 w-3.5" filled={favoritesOnly} /> Starred
            </button>
            <div className="relative">
              <select
                value={sort}
                onChange={(event) => setSort(event.target.value as SortKey)}
                aria-label="Sort installs"
                className="appearance-none rounded-xl border border-white/[0.08] bg-panel/70 py-2.5 pl-3 pr-8 text-[12px] text-fog outline-none transition hover:text-chalk"
              >
                {SORTS.map((option) => (
                  <option key={option.key} value={option.key} className="bg-panel">
                    {option.label}
                  </option>
                ))}
              </select>
              <span className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2 text-[9px] text-white/40">
                ▼
              </span>
            </div>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-1.5">
          <button
            type="button"
            onClick={() => setPlatform("all")}
            className={`rounded-full border px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] transition ${
              platform === "all"
                ? "border-white/25 bg-white/10 text-chalk"
                : "border-white/[0.07] text-white/40 hover:border-white/20 hover:text-chalk"
            }`}
          >
            all · {videos.length}
          </button>
          {platforms.map(([key, count]) => {
            const meta = PLATFORM_META[key];
            const active = platform === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setPlatform(active ? "all" : key)}
                className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] transition ${
                  active
                    ? "text-black"
                    : "border-white/[0.07] text-white/45 hover:border-white/20 hover:text-chalk"
                }`}
                style={
                  active
                    ? { backgroundColor: meta.accent, borderColor: meta.accent }
                    : undefined
                }
              >
                <span
                  className="h-1.5 w-1.5 rounded-full"
                  style={{ backgroundColor: active ? "rgba(0,0,0,0.6)" : meta.accent }}
                />
                {meta.label.toLowerCase()} · {count}
              </button>
            );
          })}
        </div>
      </div>

      {filtered.length > 0 ? (
        <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {filtered.map((video) => (
            <article
              key={video.id}
              className="group relative overflow-hidden rounded-2xl border border-white/[0.07] bg-panel/60 transition duration-300 hover:-translate-y-0.5 hover:border-white/20 hover:bg-panel"
            >
              <Link href={`/v/${video.slug}`} className="block">
                <div className="relative aspect-video overflow-hidden">
                  <Thumb
                    src={video.thumbnailUrl}
                    alt={video.title}
                    platform={video.platform}
                    title={video.title}
                    className="h-full w-full"
                  />
                  <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-black/75 via-black/5 to-black/25" />
                  <div className="absolute left-2.5 top-2.5">
                    <PlatformBadge platform={video.platform} />
                  </div>
                  <span className="absolute left-1/2 top-1/2 grid h-11 w-11 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-black/50 text-white opacity-0 backdrop-blur-sm transition duration-300 group-hover:opacity-100">
                    <PlayIcon className="h-4 w-4 translate-x-[1px]" />
                  </span>
                  <div className="absolute inset-x-2.5 bottom-2.5 flex items-center justify-between gap-2 font-mono text-[9px] uppercase tracking-[0.14em] text-white/65">
                    <span className="truncate">{hostOf(video.canonicalUrl)}</span>
                    {video.installCount > 1 && (
                      <span className="shrink-0 rounded-full bg-white/10 px-1.5 py-0.5 text-white/80">
                        ×{video.installCount}
                      </span>
                    )}
                  </div>
                </div>
                <div className="p-3.5">
                  <h3 className="line-clamp-2 min-h-[36px] text-[13.5px] font-semibold leading-snug text-chalk transition group-hover:text-white">
                    {video.title}
                  </h3>
                  <div className="mt-2 flex items-center justify-between gap-2 text-[11px] text-fog">
                    <span className="min-w-0 truncate">
                      {video.authorName ?? hostOf(video.canonicalUrl)}
                    </span>
                    <span className="shrink-0 font-mono text-[9px] uppercase tracking-[0.12em] text-white/30">
                      {timeAgo(video.createdAt)}
                    </span>
                  </div>
                </div>
              </Link>
              <button
                type="button"
                onClick={() => void toggleFavorite(video)}
                aria-label={video.favorite ? "Remove from favourites" : "Save to favourites"}
                className={`absolute right-2.5 top-2.5 z-10 grid h-8 w-8 place-items-center rounded-full border backdrop-blur transition ${
                  video.favorite
                    ? "border-lime/40 bg-lime/20 text-lime"
                    : "border-white/15 bg-black/45 text-white/70 hover:border-lime/40 hover:text-lime"
                }`}
              >
                <StarIcon className="h-3.5 w-3.5" filled={video.favorite} />
              </button>
            </article>
          ))}
        </div>
      ) : (
        <div className="mt-6 rounded-2xl border border-dashed border-white/12 bg-panel/40 px-6 py-14 text-center">
          <span className="mx-auto grid h-12 w-12 place-items-center rounded-full border border-white/10 bg-white/[0.04] text-white/50">
            {videos.length === 0 ? <LinkIcon className="h-5 w-5" /> : <SearchIcon className="h-5 w-5" />}
          </span>
          <h3 className="mt-4 text-[16px] font-semibold text-chalk">
            {videos.length === 0 ? "Nothing installed yet" : "No installs match those filters"}
          </h3>
          <p className="mx-auto mt-1.5 max-w-sm text-[13px] leading-relaxed text-fog">
            {videos.length === 0
              ? "Paste a YouTube, TikTok, Vimeo or direct video link above and it lands here with its own player page."
              : "Try a different search, or reset the filters to see the whole library."}
          </p>
          {videos.length === 0 ? (
            <a
              href="#install"
              className="mt-5 inline-flex items-center gap-2 rounded-full bg-lime px-4 py-2 text-[12.5px] font-semibold text-black"
            >
              <SparkIcon className="h-4 w-4" /> Install your first video
            </a>
          ) : (
            <button
              type="button"
              onClick={resetFilters}
              className="mt-5 inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-2 text-[12.5px] text-chalk transition hover:border-white/30"
            >
              Reset filters
            </button>
          )}
        </div>
      )}

      <div className="mt-5 flex items-center justify-between">
        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-white/30">
          showing {filtered.length} of {videos.length}
        </p>
        <p aria-live="polite" className="text-[11px] text-lime/80">
          {message}
        </p>
      </div>
    </div>
  );
}
