"use client";

import { useState } from "react";
import { proxyMediaUrl } from "@/lib/format";
import { PLATFORM_META, type VideoDTO } from "@/lib/types";
import { ExternalIcon, FilmIcon, LinkIcon, PlatformIcon, PlayIcon } from "./icons";

export function Player({ video }: { video: VideoDTO }) {
  const mediaKey = `${video.id}:${video.embedUrl ?? ""}`;
  const [failedKey, setFailedKey] = useState<string | null>(null);
  const failed = failedKey === mediaKey;
  const meta = PLATFORM_META[video.platform];
  const vertical = video.platform === "tiktok" || video.platform === "instagram";

  const canFrame = !failed && video.playerKind === "iframe" && Boolean(video.embedUrl);
  const canPlay = !failed && video.playerKind === "video" && Boolean(video.embedUrl);

  return (
    <div>
      <div className="overflow-hidden rounded-2xl border border-white/[0.08] bg-black shadow-[0_30px_80px_-40px_rgba(0,0,0,0.9)]">
        <div className={vertical ? "mx-auto w-full max-w-[400px]" : "w-full"}>
          <div className={vertical ? "aspect-[9/16]" : "aspect-video"}>
            {canFrame ? (
              <iframe
                key={video.embedUrl}
                src={video.embedUrl ?? ""}
                title={video.title}
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen"
                allowFullScreen
                loading="lazy"
                referrerPolicy="strict-origin-when-cross-origin"
                className="h-full w-full border-0"
              />
            ) : canPlay ? (
              <video
                key={video.embedUrl}
                controls
                playsInline
                preload="metadata"
                poster={video.thumbnailUrl ?? undefined}
                onError={() => setFailedKey(mediaKey)}
                className="h-full w-full bg-black"
              >
                <source src={proxyMediaUrl(video.embedUrl ?? video.canonicalUrl)} />
              </video>
            ) : (
              <div className="relative grid h-full w-full place-items-center overflow-hidden px-6 text-center">
                <div
                  className="absolute inset-0"
                  style={{
                    background: `radial-gradient(120% 120% at 20% 0%, ${meta.tint}, #0a0a0f 60%)`,
                  }}
                />
                <div className="relative">
                  <span
                    className="mx-auto grid h-14 w-14 place-items-center rounded-2xl border border-white/12 bg-black/40"
                    style={{ color: meta.accent }}
                  >
                    {video.platform === "file" ? (
                      <FilmIcon className="h-6 w-6" />
                    ) : video.playerKind === "link" ? (
                      <LinkIcon className="h-6 w-6" />
                    ) : (
                      <PlatformIcon platform={video.platform} className="h-6 w-6" />
                    )}
                  </span>
                  <h3 className="mt-4 text-[15px] font-semibold text-chalk">
                    {failed
                      ? "This player would not load"
                      : video.playerKind === "link"
                        ? "Saved as a reference link"
                        : "No inline player available"}
                  </h3>
                  <p className="mx-auto mt-1.5 max-w-xs text-[12.5px] leading-relaxed text-white/50">
                    {failed
                      ? "The source blocked the embed or the file is unreachable. Open it directly on the platform."
                      : `${meta.label} does not offer an embeddable player for this url, so the install keeps the original link and its metadata.`}
                  </p>
                  <a
                    href={video.canonicalUrl}
                    target="_blank"
                    rel="noreferrer noopener"
                    className="mt-4 inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-[12.5px] font-medium text-chalk transition hover:bg-white/15"
                  >
                    <ExternalIcon className="h-3.5 w-3.5" /> Open original
                  </a>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="mt-2.5 flex flex-wrap items-center justify-between gap-2 px-1">
        <p className="flex items-center gap-1.5 font-mono text-[9.5px] uppercase tracking-[0.16em] text-white/30">
          <PlayIcon className="h-2.5 w-2.5" style={{ color: meta.accent }} />
          {video.playerKind === "iframe"
            ? `embedded ${meta.label.toLowerCase()} player`
            : video.playerKind === "video"
              ? "native file playback via proxy"
              : "reference only"}
        </p>
        <p className="text-[11px] text-white/35">
          Player blocked?{" "}
          <a
            href={video.canonicalUrl}
            target="_blank"
            rel="noreferrer noopener"
            className="text-white/70 underline decoration-white/25 underline-offset-2 transition hover:text-lime"
          >
            Watch at the source
          </a>
        </p>
      </div>
    </div>
  );
}
