import Link from "next/link";
import { LinkIcon, LogoMark } from "./icons";

export function SiteHeader() {
  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.06] bg-ink/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center justify-between gap-4 px-5">
        <Link href="/" className="group flex items-center gap-2.5">
          <LogoMark className="h-8 w-8" />
          <span className="text-[17px] font-semibold tracking-[-0.02em] text-chalk">
            reelbase<span className="text-lime">.</span>
          </span>
        </Link>

        <nav className="hidden items-center gap-7 text-[13px] text-fog md:flex">
          <Link className="transition hover:text-chalk" href="/#library">
            Library
          </Link>
          <Link className="transition hover:text-chalk" href="/#how">
            How it works
          </Link>
          <Link className="transition hover:text-chalk" href="/#platforms">
            Supported links
          </Link>
        </nav>

        <Link
          href="/#install"
          className="inline-flex items-center gap-2 rounded-full bg-lime px-4 py-2 text-[13px] font-semibold text-black transition hover:bg-[#e6ff7a]"
        >
          <LinkIcon className="h-4 w-4" />
          Install a link
        </Link>
      </div>
    </header>
  );
}

export function SiteFooter() {
  return (
    <footer className="mt-24 border-t border-white/[0.06] bg-black/30">
      <div className="mx-auto grid w-full max-w-6xl gap-8 px-5 py-12 md:grid-cols-[1.2fr_1fr_1fr]">
        <div>
          <div className="flex items-center gap-2.5">
            <LogoMark className="h-7 w-7" />
            <span className="text-[15px] font-semibold tracking-[-0.02em]">reelbase</span>
          </div>
          <p className="mt-3 max-w-sm text-[13px] leading-relaxed text-fog">
            A link-in, player-out video library. Paste a url, we resolve the video, store its
            identity, and keep a permanent install page for it.
          </p>
        </div>
        <div className="text-[13px] text-fog">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/35">Built with</p>
          <ul className="mt-3 space-y-1.5">
            <li>Next.js App Router</li>
            <li>PostgreSQL + Drizzle ORM</li>
            <li>Platform oEmbed resolution</li>
          </ul>
        </div>
        <div className="text-[13px] text-fog">
          <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-white/35">The fine print</p>
          <p className="mt-3 leading-relaxed">
            No video files are ripped or re-hosted. Installations reference the original source, and
            playback happens on the platform&apos;s own player. Direct file links stream through a
            proxy so you can preview them.
          </p>
        </div>
      </div>
      <div className="border-t border-white/[0.05] px-5 py-5">
        <p className="mx-auto flex w-full max-w-6xl flex-wrap items-center justify-between gap-2 font-mono text-[10px] uppercase tracking-[0.18em] text-white/30">
          <span>reelbase — install videos, not downloads</span>
          <span>{new Date().getFullYear()} · local library instance</span>
        </p>
      </div>
    </footer>
  );
}
