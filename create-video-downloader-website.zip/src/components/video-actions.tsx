"use client";

import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import { proxyMediaUrl } from "@/lib/format";
import type { VideoDTO } from "@/lib/types";
import {
  CheckIcon,
  CopyIcon,
  DownloadIcon,
  ExternalIcon,
  NoteIcon,
  RefreshIcon,
  StarIcon,
  TrashIcon,
} from "./icons";

type Status = { kind: "ok" | "error"; message: string } | null;

export function VideoActions({ video }: { video: VideoDTO }) {
  const router = useRouter();
  const [favorite, setFavorite] = useState(video.favorite);
  const [note, setNote] = useState(video.note ?? "");
  const [savedNote, setSavedNote] = useState(video.note ?? "");
  const [savingNote, setSavingNote] = useState(false);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState<Status>(null);

  useEffect(() => {
    setFavorite(video.favorite);
    setNote(video.note ?? "");
    setSavedNote(video.note ?? "");
  }, [video.id, video.favorite, video.note]);

  useEffect(() => {
    if (!status) return;
    const timer = window.setTimeout(() => setStatus(null), 3600);
    return () => window.clearTimeout(timer);
  }, [status]);

  async function saveFavorite(next: boolean) {
    setFavorite(next);
    try {
      const response = await fetch(`/api/videos/${video.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ favorite: next }),
      });
      if (!response.ok) throw new Error("failed");
      setStatus({
        kind: "ok",
        message: next ? "Starred this install." : "Removed from starred.",
      });
      router.refresh();
    } catch {
      setFavorite(!next);
      setStatus({ kind: "error", message: "Could not update this install." });
    }
  }

  async function saveNote() {
    setSavingNote(true);
    try {
      const response = await fetch(`/api/videos/${video.id}`, {
        method: "PATCH",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ note }),
      });
      const data = (await response.json()) as { ok?: boolean; error?: string };
      if (!response.ok || !data.ok) throw new Error(data.error ?? "failed");
      setSavedNote(note);
      setStatus({ kind: "ok", message: "Note saved." });
      router.refresh();
    } catch {
      setStatus({ kind: "error", message: "Could not save that note." });
    } finally {
      setSavingNote(false);
    }
  }

  async function refreshMetadata() {
    setBusy(true);
    try {
      const response = await fetch(`/api/videos/${video.id}/refresh`, { method: "POST" });
      const data = (await response.json()) as { ok?: boolean; error?: string; resolved?: boolean };
      if (!response.ok || !data.ok) throw new Error(data.error ?? "failed");
      setStatus({
        kind: data.resolved ? "ok" : "error",
        message: data.resolved
          ? "Details re-fetched from the platform."
          : "The platform did not return details. Kept the existing metadata.",
      });
      router.refresh();
    } catch {
      setStatus({ kind: "error", message: "Metadata refresh failed." });
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    const confirmed = window.confirm(
      `Remove “${video.title}” from your library? The source video is not affected.`,
    );
    if (!confirmed) return;
    setBusy(true);
    try {
      const response = await fetch(`/api/videos/${video.id}`, { method: "DELETE" });
      if (!response.ok) throw new Error("failed");
      router.push("/?removed=1");
      router.refresh();
    } catch {
      setStatus({ kind: "error", message: "Could not remove this install." });
      setBusy(false);
    }
  }

  async function copyLink() {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      window.setTimeout(() => setCopied(false), 2200);
    } catch {
      setStatus({ kind: "error", message: "Clipboard is blocked by your browser." });
    }
  }

  const noteDirty = note !== savedNote;

  return (
    <div className="space-y-3">
      <div className="rounded-2xl border border-white/[0.08] bg-panel/60 p-3.5">
        <div className="flex items-center justify-between">
          <p className="font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/35">actions</p>
          <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/25">
            id {video.id}
          </span>
        </div>

        <div className="mt-3 grid grid-cols-2 gap-2">
          <button
            type="button"
            onClick={() => void saveFavorite(!favorite)}
            className={`inline-flex items-center justify-center gap-1.5 rounded-xl border px-3 py-2.5 text-[12px] font-medium transition ${
              favorite
                ? "border-lime/40 bg-lime/10 text-lime"
                : "border-white/10 bg-white/[0.03] text-fog hover:border-white/25 hover:text-chalk"
            }`}
          >
            <StarIcon className="h-3.5 w-3.5" filled={favorite} />
            {favorite ? "Starred" : "Star"}
          </button>

          <button
            type="button"
            onClick={() => void copyLink()}
            className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] font-medium text-fog transition hover:border-white/25 hover:text-chalk"
          >
            {copied ? <CheckIcon className="h-3.5 w-3.5" /> : <CopyIcon className="h-3.5 w-3.5" />}
            {copied ? "Copied" : "Copy page"}
          </button>

          <a
            href={video.canonicalUrl}
            target="_blank"
            rel="noreferrer noopener"
            className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] font-medium text-fog transition hover:border-white/25 hover:text-chalk"
          >
            <ExternalIcon className="h-3.5 w-3.5" /> Source
          </a>

          {video.playerKind === "video" ? (
            <a
              href={proxyMediaUrl(video.embedUrl ?? video.canonicalUrl, true)}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] font-medium text-fog transition hover:border-white/25 hover:text-chalk"
            >
              <DownloadIcon className="h-3.5 w-3.5" /> Download
            </a>
          ) : (
            <button
              type="button"
              disabled={busy}
              onClick={() => void refreshMetadata()}
              className="inline-flex items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2.5 text-[12px] font-medium text-fog transition hover:border-white/25 hover:text-chalk disabled:opacity-50"
            >
              <RefreshIcon className={`h-3.5 w-3.5 ${busy ? "animate-spin" : ""}`} /> Refresh
            </button>
          )}
        </div>

        {video.playerKind === "video" && (
          <button
            type="button"
            disabled={busy}
            onClick={() => void refreshMetadata()}
            className="mt-2 inline-flex w-full items-center justify-center gap-1.5 rounded-xl border border-white/10 bg-white/[0.03] px-3 py-2 text-[11.5px] text-fog transition hover:border-white/25 hover:text-chalk disabled:opacity-50"
          >
            <RefreshIcon className={`h-3.5 w-3.5 ${busy ? "animate-spin" : ""}`} /> Refresh file
            details
          </button>
        )}

        {status && (
          <p
            role="status"
            className={`mt-2.5 rounded-lg border px-2.5 py-2 text-[11.5px] ${
              status.kind === "ok"
                ? "border-lime/25 bg-lime/[0.06] text-lime"
                : "border-amber-300/25 bg-amber-300/[0.06] text-amber-200"
            }`}
          >
            {status.message}
          </p>
        )}
      </div>

      <div className="rounded-2xl border border-white/[0.08] bg-panel/60 p-3.5">
        <div className="flex items-center justify-between">
          <p className="flex items-center gap-1.5 font-mono text-[9.5px] uppercase tracking-[0.2em] text-white/35">
            <NoteIcon className="h-3 w-3" /> your note
          </p>
          {noteDirty && (
            <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-amber-200/80">
              unsaved
            </span>
          )}
        </div>
        <textarea
          value={note}
          onChange={(event) => setNote(event.target.value)}
          rows={3}
          maxLength={600}
          placeholder="Why is this here? Add a reminder, a timestamp, a playlist idea…"
          className="mt-2.5 w-full resize-none rounded-xl border border-white/[0.07] bg-black/35 p-3 text-[12.5px] leading-relaxed text-chalk outline-none transition placeholder:text-white/25 focus:border-lime/40"
        />
        <div className="mt-2 flex items-center justify-between gap-2">
          <span className="font-mono text-[9px] uppercase tracking-[0.14em] text-white/25">
            {note.length}/600
          </span>
          <div className="flex gap-2">
            {noteDirty && (
              <button
                type="button"
                onClick={() => setNote(savedNote)}
                className="rounded-lg px-2.5 py-1.5 text-[11px] text-white/45 transition hover:text-white"
              >
                Cancel
              </button>
            )}
            <button
              type="button"
              disabled={!noteDirty || savingNote}
              onClick={() => void saveNote()}
              className="rounded-lg bg-lime px-3 py-1.5 text-[11.5px] font-semibold text-black transition hover:bg-[#e8ff83] disabled:cursor-not-allowed disabled:opacity-40"
            >
              {savingNote ? "Saving…" : "Save note"}
            </button>
          </div>
        </div>
      </div>

      <button
        type="button"
        disabled={busy}
        onClick={() => void remove()}
        className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-red-400/20 bg-red-500/[0.05] px-3 py-2.5 text-[12px] font-medium text-red-300/90 transition hover:border-red-400/40 hover:bg-red-500/10 disabled:opacity-50"
      >
        <TrashIcon className="h-3.5 w-3.5" /> Uninstall from library
      </button>
    </div>
  );
}
